const API_URL =
    "https://Dasbrodkingsz.admin/api/api.php";

let adminToken =
    sessionStorage.getItem("kingsz_admin_token") || "";

let websiteData = null;


/* ================= HELPER ================= */

const $ = (selector) =>
    document.querySelector(selector);


function escapeHTML(text = "") {

    return text.replace(
        /[&<>"']/g,
        (char) => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[char]
    );
}


/* ================= API ================= */

async function apiRequest(action, options = {}) {

    const isFormData =
        options.body instanceof FormData;

    const headers = isFormData
        ? {
            "X-Admin-Token": adminToken
        }
        : {
            "Content-Type": "application/json",
            "X-Admin-Token": adminToken
        };

    const response = await fetch(
        `${API_URL}?action=${action}`,
        {
            ...options,
            headers
        }
    );

    const data =
        await response.json();

    if (!response.ok) {

        throw new Error(
            data.message ||
            "Terjadi kesalahan."
        );

    }

    return data;
}


/* ================= LOGIN ================= */

$("#loginForm").addEventListener(
    "submit",
    async (event) => {

        event.preventDefault();

        const username =
            $("#username").value;

        const password =
            $("#password").value;

        $("#loginMessage").textContent =
            "Memeriksa login...";

        try {

            const result =
                await apiRequest(
                    "login",
                    {
                        method: "POST",

                        body:
                            JSON.stringify({
                                username,
                                password
                            })
                    }
                );

            adminToken =
                result.token;

            sessionStorage.setItem(
                "kingsz_admin_token",
                adminToken
            );

            showDashboard();

        } catch (error) {

            $("#loginMessage").textContent =
                error.message;

        }

    }
);


/* ================= DASHBOARD ================= */

function showDashboard() {

    $("#loginPage")
        .classList
        .add("hidden");

    $("#dashboard")
        .classList
        .remove("hidden");

    loadData();
}


/* ================= LOAD DATA ================= */

async function loadData() {

    try {

        websiteData =
            await apiRequest("data");

        renderDashboard();

    } catch (error) {

        alert(error.message);

    }

}


/* ================= RENDER ================= */

function renderDashboard() {

    const links =
        websiteData.links || [];

    const profile =
        websiteData.profile || {};

    $("#totalLinks").textContent =
        links.length;

    $("#activeLinks").textContent =
        links.filter(
            link => link.active
        ).length;

    $("#profileNameStat").textContent =
        profile.name || "-";


    $("#profileName").value =
        profile.name || "";

    $("#profileBio").value =
        profile.bio || "";

    $("#previewName").textContent =
        profile.name || "";

    $("#previewBio").textContent =
        profile.bio || "";

    $("#profilePreview").src =
        profile.photo || "";


    $("#primaryColor").value =
        websiteData.theme?.primary ||
        "#2563eb";

    $("#backgroundColor").value =
        websiteData.theme?.background ||
        "#eef6ff";

    $("#fontFamily").value =
        websiteData.theme?.font ||
        "Poppins";


    renderLinks();

}


/* ================= LINK LIST ================= */

function renderLinks() {

    const container =
        $("#linkList");

    const links =
        [...websiteData.links]
            .sort(
                (a, b) =>
                    (a.order || 0) -
                    (b.order || 0)
            );


    if (!links.length) {

        container.innerHTML =
            "<p>Belum ada link.</p>";

        return;
    }


    container.innerHTML =
        links.map(
            (link) => `

            <div
                class="link-row"
                data-id="${escapeHTML(link.id)}"
            >

                <div class="link-icon">

                    ${
                        link.icon
                        ?
                        `<img
                            src="${escapeHTML(link.icon)}"
                            alt=""
                        >`
                        :
                        escapeHTML(
                            link.emoji || "↗"
                        )
                    }

                </div>


                <div>

                    <div class="link-name">

                        ${escapeHTML(link.name)}

                        <span
                            class="
                            status
                            ${link.active
                                ? ""
                                : "off"}
                            "
                        >

                            ${
                                link.active
                                ? "Aktif"
                                : "Nonaktif"
                            }

                        </span>

                    </div>

                    <span class="link-url">

                        ${escapeHTML(link.url)}

                    </span>

                </div>


                <div class="actions">

                    <button
                        class="action-button"
                        onclick="
                            moveLink(
                                '${link.id}',
                                -1
                            )
                        "
                    >
                        ↑
                    </button>


                    <button
                        class="action-button"
                        onclick="
                            moveLink(
                                '${link.id}',
                                1
                            )
                        "
                    >
                        ↓
                    </button>


                    <button
                        class="action-button"
                        onclick="
                            toggleLink(
                                '${link.id}'
                            )
                        "
                    >
                        ${link.active ? "●" : "○"}
                    </button>


                    <button
                        class="action-button"
                        onclick="
                            editLink(
                                '${link.id}'
                            )
                        "
                    >
                        ✎
                    </button>


                    <button
                        class="
                            action-button
                            delete
                        "
                        onclick="
                            deleteLink(
                                '${link.id}'
                            )
                        "
                    >
                        ×
                    </button>

                </div>

            </div>

        `
        ).join("");

}


/* ================= SAVE ================= */

async function saveData() {

    await apiRequest(
        "save",
        {
            method: "POST",

            body:
                JSON.stringify(
                    websiteData
                )
        }
    );

    renderDashboard();

    showMessage(
        "Perubahan berhasil disimpan."
    );
}


/* ================= MESSAGE ================= */

function showMessage(message) {

    const title =
        $("#pageTitle");

    const old =
        title.textContent;

    title.textContent =
        message;

    setTimeout(() => {

        title.textContent =
            old;

    }, 1500);

}


/* ================= PROFILE ================= */

$("#profileForm")
    .addEventListener(
        "submit",
        async (event) => {

            event.preventDefault();

            websiteData.profile.name =
                $("#profileName").value;

            websiteData.profile.bio =
                $("#profileBio").value;


            const photo =
                $("#profilePhoto")
                    .files[0];

            const banner =
                $("#profileBanner")
                    .files[0];


            if (photo) {

                websiteData.profile.photo =
                    await uploadFile(photo);

            }


            if (banner) {

                websiteData.profile.banner =
                    await uploadFile(banner);

            }


            await saveData();

        }
    );


/* ================= UPLOAD ================= */

async function uploadFile(file) {

    const formData =
        new FormData();

    formData.append(
        "file",
        file
    );

    const result =
        await apiRequest(
            "upload",
            {
                method: "POST",
                body: formData
            }
        );

    return result.url;
}


/* ================= ADD LINK ================= */

$("#addLinkButton")
    .addEventListener(
        "click",
        () => {

            openLinkModal();

        }
    );


function openLinkModal(link = null) {

    $("#modalTitle").textContent =
        link
        ? "Edit Link"
        : "Tambah Link";


    $("#linkId").value =
        link?.id || "";

    $("#linkName").value =
        link?.name || "";

    $("#linkUrl").value =
        link?.url || "";

    $("#linkEmoji").value =
        link?.emoji || "";

    $("#linkStatus").checked =
        link
        ? Boolean(link.active)
        : true;


    $("#linkIcon").value = "";

    $("#linkModal").showModal();

}


/* ================= SAVE LINK ================= */

$("#linkForm")
    .addEventListener(
        "submit",
        async (event) => {

            event.preventDefault();

            const id =
                $("#linkId").value ||
                crypto.randomUUID();


            let link =
                websiteData.links
                    .find(
                        item =>
                            item.id === id
                    );


            if (!link) {

                link = {

                    id,

                    order:
                        websiteData.links.length + 1

                };

                websiteData.links.push(link);

            }


            link.name =
                $("#linkName").value;

            link.url =
                $("#linkUrl").value;

            link.emoji =
                $("#linkEmoji").value;

            link.active =
                $("#linkStatus").checked;


            const icon =
                $("#linkIcon")
                    .files[0];


            if (icon) {

                link.icon =
                    await uploadFile(icon);

            }


            $("#linkModal").close();

            await saveData();

        }
    );


/* ================= EDIT ================= */

function editLink(id) {

    const link =
        websiteData.links.find(
            item =>
                item.id === id
        );

    if (link) {

        openLinkModal(link);

    }

}


/* ================= DELETE ================= */

async function deleteLink(id) {

    const confirmDelete =
        confirm(
            "Yakin ingin menghapus link ini?"
        );

    if (!confirmDelete) return;


    websiteData.links =
        websiteData.links.filter(
            link =>
                link.id !== id
        );


    reorderLinks();

    await saveData();

}


/* ================= TOGGLE ================= */

async function toggleLink(id) {

    const link =
        websiteData.links.find(
            item =>
                item.id === id
        );

    if (!link) return;

    link.active =
        !link.active;

    await saveData();

}


/* ================= ORDER ================= */

async function moveLink(
    id,
    direction
) {

    const links =
        [...websiteData.links]
            .sort(
                (a, b) =>
                    (a.order || 0) -
                    (b.order || 0)
            );


    const index =
        links.findIndex(
            item =>
                item.id === id
        );


    const target =
        index + direction;


    if (
        target < 0 ||
        target >= links.length
    ) return;


    [
        links[index].order,
        links[target].order
    ] = [
        links[target].order,
        links[index].order
    ];


    websiteData.links =
        links;


    await saveData();

}


function reorderLinks() {

    websiteData.links
        .forEach(
            (link, index) => {

                link.order =
                    index + 1;

            }
        );

}


/* ================= THEME ================= */

$("#saveTheme")
    .addEventListener(
        "click",
        async () => {

            websiteData.theme = {

                primary:
                    $("#primaryColor").value,

                background:
                    $("#backgroundColor").value,

                font:
                    $("#fontFamily").value

            };


            await saveData();

        }
    );


/* ================= NAVIGATION ================= */

document
    .querySelectorAll(".nav-button")
    .forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    document
                        .querySelectorAll(
                            ".nav-button"
                        )
                        .forEach(
                            item =>
                                item.classList
                                    .remove(
                                        "active"
                                    )
                        );


                    button.classList
                        .add("active");


                    document
                        .querySelectorAll(
                            ".content-section"
                        )
                        .forEach(
                            section =>
                                section.classList
                                    .remove(
                                        "active"
                                    )
                        );


                    const section =
                        button.dataset.section;


                    $("#" + section)
                        .classList
                        .add("active");


                    $("#pageTitle")
                        .textContent =
                        button.textContent
                            .replace(
                                /[^\p{L}\p{N}\s]/gu,
                                ""
                            )
                            .trim();


                    if (
                        section === "code"
                    ) {

                        showCode();

                    }

                }
            );

        }
    );


/* ================= LOGOUT ================= */

$("#logoutButton")
    .addEventListener(
        "click",
        () => {

            sessionStorage.removeItem(
                "kingsz_admin_token"
            );

            location.reload();

        }
    );


/* ================= MODAL ================= */

$("#closeModal")
    .onclick =
    () => $("#linkModal").close();

$("#cancelModal")
    .onclick =
    () => $("#linkModal").close();


/* ================= CODE VIEWER ================= */

/*
    Masukkan isi file coding
    ke object codeFiles jika
    ingin ditampilkan otomatis.
*/

const codeFiles = {

    "admin-html":
`<!-- Isi admin/index.html -->`,

    "admin-css":
`/* Isi admin/style.css */`,

    "admin-js":
`// Isi admin/script.js`,

    "frontend-html":
`<!-- Isi frontend/index.html -->`,

    "frontend-css":
`/* Isi frontend/style.css */`,

    "frontend-js":
`// Isi frontend/script.js`,

    "api":
`<?php
// Isi api/api.php
?>`

};


function showCode() {

    const selected =
        $("#codeFile").value;

    $("#codeViewer").textContent =
        codeFiles[selected] || "";

}


$("#codeFile")
    .addEventListener(
        "change",
        showCode
    );


$("#copyCode")
    .addEventListener(
        "click",
        async () => {

            await navigator.clipboard
                .writeText(
                    $("#codeViewer")
                        .textContent
                );

            showMessage(
                "Coding berhasil disalin."
            );

        }
    );


/* ================= START ================= */

if (adminToken) {

    showDashboard();

}