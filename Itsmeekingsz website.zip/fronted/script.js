const API_URL =
    "https://Dasbrodkingsz.admin/api/api.php?action=data";


const defaultData = {

    profile: {

        name:
            "Kingsz Remaja",

        bio:
            "Semua link penting Kingsz Remaja ada di sini.",

        photo: "",

        banner: ""

    },


    theme: {

        primary:
            "#2563eb",

        background:
            "#eef6ff",

        font:
            "Poppins"

    },


    links: [

        {
            id: "instagram",

            name: "Instagram",

            url:
                "https://instagram.com/",

            icon: "",

            emoji: "◎",

            active: true,

            order: 1
        },


        {
            id: "tiktok",

            name: "TikTok",

            url:
                "https://tiktok.com/",

            icon: "",

            emoji: "♪",

            active: true,

            order: 2
        },


        {
            id: "youtube",

            name: "YouTube",

            url:
                "https://youtube.com/",

            icon: "",

            emoji: "▶",

            active: true,

            order: 3
        }

    ]

};


/* ================= HELPERS ================= */

const $ =
    selector =>
        document.querySelector(
            selector
        );


function escapeHTML(text = "") {

    return text.replace(
        /[&<>"']/g,

        char =>
            ({
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            })[char]
    );

}


/* ================= LOAD ================= */

async function loadWebsite() {

    let data =
        defaultData;


    try {

        const response =
            await fetch(
                API_URL,
                {
                    cache: "no-store"
                }
            );


        if (response.ok) {

            data =
                await response.json();

        }

    } catch (error) {

        console.warn(
            "API tidak tersedia.",
            error
        );

    }


    renderWebsite(data);

}


/* ================= RENDER ================= */

function renderWebsite(data) {

    const profile =
        data.profile ||
        defaultData.profile;


    const theme =
        data.theme ||
        defaultData.theme;


    /* THEME */

    document.documentElement
        .style
        .setProperty(
            "--primary",
            theme.primary ||
            "#2563eb"
        );


    document.documentElement
        .style
        .setProperty(
            "--background",
            theme.background ||
            "#eef6ff"
        );


    document.body.style.fontFamily =
        `${theme.font || "Poppins"},
         Inter,
         sans-serif`;


    /* PROFILE */

    $("#profileName")
        .textContent =
        profile.name ||
        "Kingsz Remaja";


    $("#profileBio")
        .textContent =
        profile.bio || "";


    if (profile.photo) {

        $("#profileImage")
            .src =
            profile.photo;

    } else {

        $("#profileImage").src =
            "data:image/svg+xml," +
            "%3Csvg xmlns='http://www.w3.org/2000/svg' " +
            "width='200' height='200'%3E" +
            "%3Crect width='100%25' height='100%25' " +
            "fill='%23dbeafe'/%3E" +
            "%3Ctext x='50%25' y='58%25' " +
            "text-anchor='middle' font-size='80' " +
            "fill='%232563eb'%3EK%3C/text%3E" +
            "%3C/svg%3E";

    }


    /* BANNER */

    if (profile.banner) {

        $("#banner")
            .style
            .backgroundImage =
            `url("${profile.banner}")`;

    }


    /* LINKS */

    const links =
        (data.links || [])
            .filter(
                link =>
                    link.active
            )
            .sort(
                (a, b) =>
                    (a.order || 0) -
                    (b.order || 0)
            );


    $("#linksContainer")
        .innerHTML =
        links.map(
            link => `

                <a
                    class="link-card"
                    href="${escapeHTML(link.url)}"
                    target="_blank"
                    rel="noopener noreferrer"
                >

                    <div class="link-icon">

                        ${
                            link.icon

                            ?

                            `<img
                                src="${escapeHTML(link.icon)}"
                                alt=""
                            >`

                            :

                            escapeHTML(
                                link.emoji ||
                                "↗"
                            )
                        }

                    </div>


                    <span class="link-name">

                        ${escapeHTML(
                            link.name
                        )}

                    </span>


                    <span class="link-arrow">
                        ›
                    </span>

                </a>

            `
        )
        .join("");

}


/* ================= SHARE ================= */

$("#shareButton")
    .addEventListener(
        "click",
        async () => {

            try {

                if (
                    navigator.share
                ) {

                    await navigator.share({

                        title:
                            document.title,

                        url:
                            window.location.href

                    });

                } else {

                    await copyWebsite();

                }

            } catch (error) {

                console.log(error);

            }

        }
    );


/* ================= COPY ================= */

$("#copyButton")
    .addEventListener(
        "click",
        copyWebsite
    );


async function copyWebsite() {

    await navigator.clipboard
        .writeText(
            window.location.href
        );


    showToast(
        "Link website berhasil disalin!"
    );

}


/* ================= TOAST ================= */

function showToast(message) {

    const toast =
        $("#toast");

    toast.textContent =
        message;

    toast.classList
        .add("show");


    setTimeout(
        () =>
            toast.classList
                .remove("show"),
        1600
    );

}


/* ================= YEAR ================= */

$("#year")
    .textContent =
    new Date()
        .getFullYear();


/* ================= START ================= */

loadWebsite();