KINGSZ LINK BIO
==============================

STRUKTUR WEBSITE
==============================

kingsz_linkbio/

├── admin/
│   ├── index.html
│   ├── style.css
│   └── script.js
│
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
│
├── api/
│   └── api.php
│
├── uploads/
│
└── README.txt


DOMAIN
==============================

ADMIN:

https://Dasbrodkingsz.admin


FRONTEND:

https://itsmeekingsz.com


ALUR DATA
==============================

Dashboard Admin
       ↓
    API PHP
       ↓
   data.json
       ↓
Website Frontend


SETUP
==============================

1. Upload folder "admin"
   ke domain admin.

2. Upload folder "frontend"
   ke domain publik.

3. Upload folder "api"
   ke domain admin.

4. Buat folder "uploads".

5. Pastikan PHP dapat menulis
   ke folder uploads.

6. API menggunakan file
   data.json sebagai penyimpanan
   data sederhana.

7. Untuk website production,
   gunakan database seperti
   MySQL untuk keamanan dan
   skalabilitas yang lebih baik.


LOGIN DEFAULT
==============================

Username:

admin


Password:

ganti-password


TOKEN:

ganti-token-anda


PENTING
==============================

JANGAN menggunakan password
dan token default untuk website
yang benar-benar online.

Sebaiknya gunakan environment
variable:

KINGSZ_ADMIN_USER
KINGSZ_ADMIN_PASS
KINGSZ_ADMIN_TOKEN


API URL
==============================

File:

admin/script.js

ubah:

https://Dasbrodkingsz.admin/api/api.php


menjadi URL API sebenarnya
jika domain berbeda.


File:

frontend/script.js

juga menggunakan URL API
yang sama.


ACODE
==============================

Project dapat dibuka di Acode
dengan membuka folder:

kingsz_linkbio/


Kemudian edit file:

admin/index.html
admin/style.css
admin/script.js

frontend/index.html
frontend/style.css
frontend/script.js

api/api.php


CATATAN DOMAIN
==============================

"Dasbrodkingsz.admin" pada
konsep ini dianggap sebagai
alamat domain admin.

Jika belum memiliki domain
tersebut, gunakan domain/subdomain
hosting yang benar-benar kamu miliki.

Contoh:

admin.itsmeekingsz.com

atau

admin.kingszremadja.com


KEAMANAN
==============================

Untuk website sungguhan:

- gunakan HTTPS
- gunakan password hash
- gunakan session server
- gunakan database MySQL
- validasi upload
- batasi ukuran upload
- batasi tipe file
- gunakan CSRF protection
- jangan menyimpan password
  asli di JavaScript
- jangan gunakan token default