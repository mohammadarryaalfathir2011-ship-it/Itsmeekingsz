<?php

header(
    "Content-Type: application/json; charset=utf-8"
);

header(
    "Access-Control-Allow-Origin: *"
);

header(
    "Access-Control-Allow-Headers: Content-Type, X-Admin-Token"
);

header(
    "Access-Control-Allow-Methods: GET, POST, OPTIONS"
);


if (
    $_SERVER["REQUEST_METHOD"] ===
    "OPTIONS"
) {

    exit;

}


/* ================= CONFIG ================= */

$dataFile =
    __DIR__ . "/data.json";


$uploadDirectory =
    dirname(__DIR__) .
    "/uploads/";


if (
    !is_dir(
        $uploadDirectory
    )
) {

    mkdir(
        $uploadDirectory,
        0755,
        true
    );

}


/* ================= DEFAULT ================= */

$defaultData = [

    "profile" => [

        "name" =>
            "Kingsz Remaja",

        "bio" =>
            "Semua link penting Kingsz Remaja ada di sini.",

        "photo" => "",

        "banner" => ""

    ],


    "theme" => [

        "primary" =>
            "#2563eb",

        "background" =>
            "#eef6ff",

        "font" =>
            "Poppins"

    ],


    "links" => [

        [
            "id" =>
                "instagram",

            "name" =>
                "Instagram",

            "url" =>
                "https://instagram.com/",

            "icon" => "",

            "emoji" =>
                "◎",

            "active" =>
                true,

            "order" =>
                1
        ],


        [
            "id" =>
                "tiktok",

            "name" =>
                "TikTok",

            "url" =>
                "https://tiktok.com/",

            "icon" => "",

            "emoji" =>
                "♪",

            "active" =>
                true,

            "order" =>
                2
        ],


        [
            "id" =>
                "youtube",

            "name" =>
                "YouTube",

            "url" =>
                "https://youtube.com/",

            "icon" => "",

            "emoji" =>
                "▶",

            "active" =>
                true,

            "order" =>
                3
        ]

    ]

];


/* ================= CREATE DATA ================= */

if (
    !file_exists(
        $dataFile
    )
) {

    file_put_contents(
        $dataFile,

        json_encode(
            $defaultData,

            JSON_PRETTY_PRINT |
            JSON_UNESCAPED_SLASHES
        )
    );

}


/* ================= FUNCTIONS ================= */

function readData()
{

    global $dataFile;

    $data =
        json_decode(
            file_get_contents(
                $dataFile
            ),
            true
        );


    return
        $data
        ?: $GLOBALS["defaultData"];

}


function writeData($data)
{

    global $dataFile;

    file_put_contents(
        $dataFile,

        json_encode(
            $data,

            JSON_PRETTY_PRINT |
            JSON_UNESCAPED_SLASHES
        ),

        LOCK_EX
    );

}


function getBody()
{

    return
        json_decode(
            file_get_contents(
                "php://input"
            ),
            true
        )
        ?: [];

}


function response(
    $data,
    $status = 200
)
{

    http_response_code(
        $status
    );

    echo json_encode(
        $data,

        JSON_UNESCAPED_SLASHES
    );

    exit;

}


/* ================= AUTH ================= */

function authenticate()
{

    $token =
        $_SERVER[
            "HTTP_X_ADMIN_TOKEN"
        ]
        ?? "";


    /*
        GANTI TOKEN INI
        SEBELUM WEBSITE
        DIGUNAKAN SECARA NYATA.
    */

    $correctToken =
        getenv(
            "KINGSZ_ADMIN_TOKEN"
        )
        ?: "ganti-token-anda";


    if (
        !hash_equals(
            $correctToken,
            $token
        )
    ) {

        response(
            [
                "ok" =>
                    false,

                "message" =>
                    "Unauthorized"
            ],
            401
        );

    }

}


/* ================= REQUEST ================= */

$method =
    $_SERVER[
        "REQUEST_METHOD"
    ];


$action =
    $_GET["action"]
    ?? "data";


/* ================= PUBLIC DATA ================= */

if (
    $method === "GET" &&
    $action === "data"
) {

    response(
        readData()
    );

}


/* ================= LOGIN ================= */

if (
    $method === "POST" &&
    $action === "login"
) {

    $body =
        getBody();


    $username =
        $body["username"]
        ?? "";


    $password =
        $body["password"]
        ?? "";


    /*
        GANTI DENGAN
        ENVIRONMENT VARIABLE
        PADA HOSTING.
    */

    $correctUsername =
        getenv(
            "KINGSZ_ADMIN_USER"
        )
        ?: "admin";


    $correctPassword =
        getenv(
            "KINGSZ_ADMIN_PASS"
        )
        ?: "ganti-password";


    $token =
        getenv(
            "KINGSZ_ADMIN_TOKEN"
        )
        ?: "ganti-token-anda";


    if (
        hash_equals(
            $correctUsername,
            $username
        )
        &&
        hash_equals(
            $correctPassword,
            $password
        )
    ) {

        response(
            [
                "ok" =>
                    true,

                "token" =>
                    $token
            ]
        );

    }


    response(
        [
            "ok" =>
                false,

            "message" =>
                "Username atau password salah."
        ],
        401
    );

}


/* ================= AUTH ================= */

authenticate();


/* ================= SAVE ================= */

if (
    $method === "POST" &&
    $action === "save"
) {

    $body =
        getBody();


    $current =
        readData();


    foreach (
        [
            "profile",
            "theme",
            "links"
        ]
        as $key
    ) {

        if (
            isset(
                $body[$key]
            )
        ) {

            $current[$key] =
                $body[$key];

        }

    }


    writeData(
        $current
    );


    response(
        [
            "ok" =>
                true,

            "data" =>
                $current
        ]
    );

}


/* ================= UPLOAD ================= */

if (
    $method === "POST" &&
    $action === "upload"
) {

    if (
        empty(
            $_FILES["file"]
        )
    ) {

        response(
            [
                "ok" =>
                    false,

                "message" =>
                    "File tidak ditemukan."
            ],
            400
        );

    }


    $file =
        $_FILES["file"];


    if (
        $file["error"] !==
        UPLOAD_ERR_OK
    ) {

        response(
            [
                "ok" =>
                    false,

                "message" =>
                    "Upload gagal."
            ],
            400
        );

    }


    if (
        $file["size"] >
        5 * 1024 * 1024
    ) {

        response(
            [
                "ok" =>
                    false,

                "message" =>
                    "Ukuran maksimal 5MB."
            ],
            400
        );

    }


    $mime =
        (
            new finfo(
                FILEINFO_MIME_TYPE
            )
        )
        ->file(
            $file["tmp_name"]
        );


    $allowed = [

        "image/jpeg" =>
            "jpg",

        "image/png" =>
            "png",

        "image/webp" =>
            "webp",

        "image/gif" =>
            "gif"

    ];


    if (
        !isset(
            $allowed[$mime]
        )
    ) {

        response(
            [
                "ok" =>
                    false,

                "message" =>
                    "Format gambar tidak didukung."
            ],
            400
        );

    }


    $filename =
        bin2hex(
            random_bytes(8)
        )
        .
        "."
        .
        $allowed[$mime];


    move_uploaded_file(
        $file["tmp_name"],

        $uploadDirectory .
        $filename
    );


    $baseURL =
        rtrim(
            dirname(
                dirname(
                    $_SERVER["SCRIPT_NAME"]
                )
            ),
            "/"
        );


    $url =
        $baseURL .
        "/uploads/" .
        $filename;


    response(
        [
            "ok" =>
                true,

            "url" =>
                $url
        ]
    );

}


/* ================= INVALID ================= */

response(
    [
        "ok" =>
            false,

        "message" =>
            "Action tidak ditemukan."
    ],
    404
);

?>